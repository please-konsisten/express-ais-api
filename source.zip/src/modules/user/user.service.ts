import type {
  StudentProfileInput,
  TeacherProfileInput,
  CreateUserInput,
  UpdateUserInput,
  ResetUserPasswordInput,
  ListUserQuery,
  UpdateStudentInput,
  ListStudentQuery,
  UpdateTeacherInput,
  ListTeacherQuery
} from "./user.schema"
import { prismaClient } from "@src/shared/lib/database"

